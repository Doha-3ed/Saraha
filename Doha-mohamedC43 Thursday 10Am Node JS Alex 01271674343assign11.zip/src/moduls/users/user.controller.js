import  Router  from "express";
import { validation } from "../../middleWare/Validation.js";
import { signUpSchema, updateSchema,updatePasswordSchema, softDeleteSchema, shareProfileSchema } from "./uservalidation.js";
import { confirmEmail, getPorfile, logIn, signUp, updatePassword, updatePorfile,softDelete, shareProfile } from "./user.service.js";
import { authenticated } from "../../middleWare/Authentication.js";
import { asyncHandler } from "../../../utilities/globalErrorHandling.js";
const userRouter=Router()

userRouter.post("/signUp",validation(signUpSchema),asyncHandler(signUp))
userRouter.get("/confirmEmail/:token",confirmEmail)
userRouter.post("/login",asyncHandler(logIn))
userRouter.get("/getProfile",authenticated,getPorfile)
userRouter.get("/shareProfile/:id",validation(shareProfileSchema),authenticated,shareProfile)
userRouter.patch("/updateProfile",validation(updateSchema),authenticated,updatePorfile)
userRouter.patch("/updatePassword",validation(updatePasswordSchema),authenticated,updatePassword)

userRouter.delete("/freezeAccount",validation(softDeleteSchema),authenticated,softDelete)

export default userRouter