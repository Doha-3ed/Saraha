import { globalError } from "../utilities/globalErrorHandling.js"
import connectionDb from "./DB/connectionDB.js"
import messageRouter from "./moduls/messages/messsage.controller.js"
import userRouter from "./moduls/users/user.controller.js"


 
export const bootstrape=async(app,express)=>{
    app.use(express.json())
    app.use("/users",userRouter)
    app.use("/messages",messageRouter)
   connectionDb()
   app.use('*',(req,res,next)=>{
   return next(new Error("invalid URL"))
   })
app.use(globalError)
}