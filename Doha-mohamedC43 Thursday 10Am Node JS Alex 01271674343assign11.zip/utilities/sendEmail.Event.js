import jwt from "jsonwebtoken";
import { EventEmitter } from "events";
import { sendEmail } from "../src/moduls/users/service/sendEmails.js";
export const eventEmail=new EventEmitter()
eventEmail.on("sendEmail",async(data)=>{
    const {email}=data
    const token=jwt.sign({email},process.env.SIGNATURE_MAIL)
    const link=`http://localhost:${process.env.PORT}/users/confirmEmail/${token}`
    await sendEmail(email,"Confirm me",`<a href='${link}'>Confirm me</a>`)
})